# Task Executor Project, Team 7 Information #
 
#############################################

  In the Team7TaskExecutorProject directory:
    - readme.txt, contains team member information;
    - Team7TaskExecutor.jar, library .jar file, you can add it to the build path of the testing project;
    - Team7TaskExecutorDev.zip, source code archive file, you can import it to your eclipse workspace or just extract it to see the source code;