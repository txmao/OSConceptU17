package edu.utdallas.blockingFIFO;

import edu.utdallas.taskExecutor.Task;

/**
 * 
 * REFERENCES: Design document page 7 & lecture slide 5 page 33 and page 34
 *
 */

public class BlockingFIFO implements BlockingFIFOInterface {
	
	private int FIFOsize;
	private Task[] taskFIFO;
	private int nextin;
	private int nextout;
	private int FIFOcount;
	private Object notfull;
	private Object notempty;
	
	public BlockingFIFO (int queueSize) {
		/* FIFOsize should be > 0 ! */
		FIFOsize = queueSize;
		taskFIFO = new Task[queueSize];
		nextin = 0;
		nextout = 0;
		FIFOcount = 0;
		notfull = new Object();
		notempty = new Object();
	}
	
	@Override
	public void put(Task aTask) throws Exception {
		while (true) {
			if (FIFOsize == FIFOcount) {
				synchronized (notfull) {
					notfull.wait();
				}
			}
			synchronized (this) {
				if (FIFOsize == FIFOcount) {
					continue;
				}
				taskFIFO[nextin] = aTask;
				nextin = (nextin + 1) % FIFOsize;
				FIFOcount ++;
				synchronized (notempty) {
					notempty.notify();
				}
				return;
			}
		}
	}
	
	@Override
	public Task take() throws Exception {
		while (true) {
			if (FIFOcount == 0) {
				synchronized (notempty) {
					notempty.wait();
				}
			}
			synchronized (this) {
				if (FIFOcount == 0) {
					continue;
				}
				Task result = taskFIFO[nextout];
				nextout = (nextout + 1) % FIFOsize;
				FIFOcount --;
				synchronized (notfull) {
					notfull.notify();
				}
				return result;
			}
		}
	}

}
