package edu.utdallas.blockingFIFO;

import edu.utdallas.taskExecutor.Task;

public interface BlockingFIFOInterface {
	/**
	 * put a Task into FIFO, append
	 * @throws Exception 
	 */
	void put(Task aTask) throws Exception;
	
	/**
	 * take a Task from FIFO, pop
	 * @throws Exception 
	 */
	Task take() throws Exception;

}
