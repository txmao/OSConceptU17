package edu.utdallas.taskExecutorImpl;

import edu.utdallas.blockingFIFO.BlockingFIFO;
import edu.utdallas.taskExecutor.Task;
import edu.utdallas.taskExecutor.TaskExecutor;

public class TaskExecutorImpl implements TaskExecutor
{
	private int threadPoolSize;
	private BlockingFIFO workFIFO;
	
	public TaskExecutorImpl(int threadPoolSize) {
		/* queue (FIFO) size set to 100 */
		this.workFIFO = new BlockingFIFO(100);
		
		this.threadPoolSize = threadPoolSize;
		/* construct the thread pool */
		for (int i=0; i<this.threadPoolSize; i++) {
			String tname = "TaskThread"+Integer.toString(i);
			Thread t = new Thread(new TaskRunner(workFIFO), tname); // need a Runnable class
			/* never terminate ! */
			t.start();
		}
	}
	
	@Override
	public void addTask(Task task)
	{
		// TODO Complete the implementation
		try {
			workFIFO.put(task);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
