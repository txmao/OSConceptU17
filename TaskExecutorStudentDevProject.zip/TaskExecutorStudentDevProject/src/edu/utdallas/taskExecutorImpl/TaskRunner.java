package edu.utdallas.taskExecutorImpl;

import edu.utdallas.blockingFIFO.BlockingFIFO;
import edu.utdallas.taskExecutor.Task;

/**
 * 
 * REFERENCES: Design document page 8
 *
 */

public class TaskRunner implements Runnable {
	private BlockingFIFO wFIFO;
	
	public TaskRunner (BlockingFIFO aFIFO) {
		this.wFIFO = aFIFO;
	}
	
	@Override
	public void run() {
		while (true) {
			try {
				Task newTask = wFIFO.take();
				newTask.execute();//SimpleTestTask invoked in test code
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
