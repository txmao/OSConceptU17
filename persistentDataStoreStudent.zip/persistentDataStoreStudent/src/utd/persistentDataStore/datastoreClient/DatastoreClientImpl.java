package utd.persistentDataStore.datastoreClient;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import utd.persistentDataStore.utils.StreamUtil;

public class DatastoreClientImpl implements DatastoreClient
{
	private static Logger logger = Logger.getLogger(DatastoreClientImpl.class);

	private InetAddress address;
	private int port;

	public DatastoreClientImpl(InetAddress address, int port)
	{
		this.address = address;
		this.port = port;
	}

	/* (non-Javadoc)
	 * @see utd.persistentDataStore.datastoreClient.DatastoreClient#write(java.lang.String, byte[])
	 */
	@Override
    public void write(String name, byte data[]) throws ClientException, ConnectionException
	{
		logger.debug("Executing Write Operation");
		try {
			logger.debug("Opening Socket");
			Socket socket = new Socket();
			SocketAddress saddr = new InetSocketAddress(address, port);
			socket.connect(saddr);
			InputStream inputStream = socket.getInputStream();
			OutputStream outputStream = socket.getOutputStream();
			
			logger.debug("Writing Message");
			StreamUtil.writeLine("write\n", outputStream);
			StreamUtil.writeLine(name+"\n", outputStream);
			StreamUtil.writeLine(Integer.toString(data.length), outputStream);//ASCII
			StreamUtil.writeData(data, outputStream);
			
			logger.debug("Respond Message");
			String respond = StreamUtil.readLine(inputStream);
			logger.debug("Respond "+respond);
		}
		catch (IOException ex) {
			throw new ConnectionException(ex.getMessage(), ex);
		}
	}

	/* (non-Javadoc)
	 * @see utd.persistentDataStore.datastoreClient.DatastoreClient#read(java.lang.String)
	 */
	@Override
    public byte[] read(String name) throws ClientException, ConnectionException
	{
		logger.debug("Executing Read Operation");
		try {
			logger.debug("Opening Socket");
			Socket socket = new Socket();
			SocketAddress saddr = new InetSocketAddress(address, port);
			socket.connect(saddr);
			InputStream inputStream = socket.getInputStream();
			OutputStream outputStream = socket.getOutputStream();
			
			logger.debug("Send Read Request");
			StreamUtil.writeLine("read\n", outputStream);
			StreamUtil.writeLine(name+"\n", outputStream);
			
			logger.debug("Respond Message");
			String respond_code = StreamUtil.readLine(inputStream);
			if ("ok".equalsIgnoreCase(respond_code)) {
				int data_size = Integer.parseInt(StreamUtil.readLine(inputStream));
				byte[] data = StreamUtil.readData(data_size, inputStream);
				return data;
			}
			else {
				throw new ClientException("File_Not_Found!");
			}
		}
		catch (IOException ex) {
			throw new ConnectionException(ex.getMessage(), ex);
		}
		//return null;
	}

	/* (non-Javadoc)
	 * @see utd.persistentDataStore.datastoreClient.DatastoreClient#delete(java.lang.String)
	 */
	@Override
    public void delete(String name) throws ClientException, ConnectionException
	{
		logger.debug("Executing Delete Operation");
		try {
			logger.debug("Opening Socket");
			Socket socket = new Socket();
			SocketAddress saddr = new InetSocketAddress(address, port);
			socket.connect(saddr);
			InputStream inputStream = socket.getInputStream();
			OutputStream outputStream = socket.getOutputStream();
			
			logger.debug("Send Delete Request");
			StreamUtil.writeLine("delete\n", outputStream);
			StreamUtil.writeLine(name+"\n", outputStream);
			
			logger.debug("Collect Delete Request Respond");
			String respond_code = StreamUtil.readLine(inputStream);
			if (!"ok".equalsIgnoreCase(respond_code)) {
				throw new ClientException("File_Not_In_Directory!");
			}
		} catch (IOException ex) {
			throw new ConnectionException(ex.getMessage(), ex);
		}
	}

	/* (non-Javadoc)
	 * @see utd.persistentDataStore.datastoreClient.DatastoreClient#directory()
	 */
	@Override
    public List<String> directory() throws ClientException, ConnectionException
	{
		logger.debug("Executing Directory Operation");
		try {
			logger.debug("Opening Socket");
			Socket socket = new Socket();
			SocketAddress saddr = new InetSocketAddress(address, port);
			socket.connect(saddr);
			InputStream inputStream = socket.getInputStream();
			OutputStream outputStream = socket.getOutputStream();
			
			logger.debug("Send Direcoty Request");
			StreamUtil.writeLine("directory\n", outputStream);
			
			logger.debug("respond message");
			// nothing to do with respond this time
			String repdcode = StreamUtil.readLine(inputStream);
			if (repdcode.equalsIgnoreCase("ok")) {
				int numoflist = Integer.parseInt(StreamUtil.readLine(inputStream));
				List<String> namelist = new ArrayList<String>();
				for (int i=0; i<numoflist; i++) {
					namelist.add(StreamUtil.readLine(inputStream));
				}
				return namelist;
			} else {
				throw new ClientException(repdcode);
			}
		} catch (IOException ex) {
			throw new ConnectionException(ex.getMessage(), ex);
		}
		//return null;
	}

}
