package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;

import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.ServerException;
import utd.persistentDataStore.utils.StreamUtil;

public class DeleteServerCommand extends ServerCommand {
	
	private static Logger logger = Logger.getLogger(DeleteServerCommand.class);
	
	public void run() throws IOException, ServerException {
		logger.debug("Debug run() in DeleteServerCommand");
		try {
			//read name
			String fname = StreamUtil.readLine(inputStream);
			List<String> namelist = FileUtil.directory();
			if (namelist.contains(fname)) {
				FileUtil.deleteData(fname);
				sendOK();
			} else {
				sendError("File_Not_In_Directory");
			}
		}
		catch (IOException ex) {
			StreamUtil.sendError("exception_error_in_DeleteServerCommand", outputStream);
			throw new ServerException(ex.getMessage());
		}
	}

}
