package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.ServerException;
import utd.persistentDataStore.utils.StreamUtil;

public class DirectoryServerCommand extends ServerCommand {
	
	private static Logger logger = Logger.getLogger(DirectoryServerCommand.class);
	
	public void run() throws IOException, ServerException {
		logger.debug("debug directory request, sever side");
		try {
			List<String> namelist = FileUtil.directory();
			int dirsize = namelist.size();
			sendOK();
			StreamUtil.writeLine(Integer.toString(dirsize), outputStream);
			for (String fl : namelist) {
				StreamUtil.writeLine(fl, outputStream);
			}
		} catch (IOException ex) {
			throw new ServerException(ex.getMessage());
		}
	}

}
