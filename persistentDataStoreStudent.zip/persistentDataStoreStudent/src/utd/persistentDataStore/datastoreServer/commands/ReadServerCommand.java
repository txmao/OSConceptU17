package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;

import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.ServerException;
import utd.persistentDataStore.utils.StreamUtil;

public class ReadServerCommand extends ServerCommand {
	
	private static Logger logger = Logger.getLogger(ReadServerCommand.class);
	
	public void run() throws IOException, ServerException {
		logger.debug("Logger Debug ReadServerCommand Run");
		try {
			//read name
			String fname = StreamUtil.readLine(inputStream);
			//List file name currently stored
			List<String> namelist = FileUtil.directory();
			if (namelist.contains(fname)) {
				byte[] data = FileUtil.readData(fname);
				int datasize = data.length;
				sendOK();
				StreamUtil.writeLine(Integer.toString(datasize)+"\n", outputStream);
				StreamUtil.writeData(data, outputStream);
			} else {
				StreamUtil.sendError("file_not_found_in_directory", outputStream);
			}
		}
		catch (IOException ex) {
			StreamUtil.sendError("exception_error_in_ReadServerCommand", outputStream);
			throw new ServerException(ex.getMessage());
		}
	}

}
