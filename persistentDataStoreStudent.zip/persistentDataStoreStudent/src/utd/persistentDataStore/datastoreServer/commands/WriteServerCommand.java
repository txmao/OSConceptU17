package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;

import org.apache.log4j.Logger;

import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.ServerException;
import utd.persistentDataStore.utils.StreamUtil;

public class WriteServerCommand extends ServerCommand {
	
	private static Logger logger = Logger.getLogger(WriteServerCommand.class);
	
	public void run() throws IOException, ServerException {
		try {
			//read name
			String fname = StreamUtil.readLine(inputStream);
			//read data size
			int fsize = Integer.parseInt(StreamUtil.readLine(inputStream));
			//read data
			byte[] fdata = StreamUtil.readData(fsize, inputStream);
			
			FileUtil.writeData(fname, fdata);
			sendOK();
		}
		catch (IOException ex) {
			logger.debug("Write Error");
			sendError(ex.getMessage());
			throw new ServerException(ex.getMessage());
		}
	}

}
